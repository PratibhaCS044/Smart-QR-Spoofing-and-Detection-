import os
import qrcode
from urllib.parse import urlparse

# Folder where generated QR images are stored
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    "static",
    "spoofed_qr"
)

os.makedirs(OUTPUT_DIR, exist_ok=True)


def generate_spoofed_qr(original_url):
    """
    Generate a controlled simulated spoofed QR code.

    The QR contains a modified/test URL so that the
    existing detection system can analyze it.
    """

    original_url = original_url.strip()

    if not original_url:
        raise ValueError("URL cannot be empty.")

    # Create a clearly controlled test URL.
    # This is for demonstrating QR spoofing detection.
    parsed = urlparse(original_url)

    if parsed.scheme and parsed.netloc:
        spoofed_url = (
            f"https://{parsed.netloc.replace('.', '-')}"
            f".qr-spoof-test.local/verify"
        )
    else:
        spoofed_url = "https://qr-spoof-test.local/verify"

    # Generate QR
    qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=4
    )

    qr.add_data(spoofed_url)
    qr.make(fit=True)

    img = qr.make_image()

    output_file = os.path.join(
        OUTPUT_DIR,
        "spoofed_qr.png"
    )

    img.save(output_file)

    return spoofed_url, output_file


if __name__ == "__main__":

    print("=== QR Spoofing Simulation ===")

    original_url = input(
        "Enter the original URL for simulation: "
    ).strip()

    try:
        spoofed_url, output_file = generate_spoofed_qr(
            original_url
        )

        print("\nOriginal URL:")
        print(original_url)

        print("\nSimulated spoofed URL:")
        print(spoofed_url)

        print("\nQR generated successfully!")
        print("Saved at:")
        print(output_file)

    except Exception as e:
        print("\nError:", e)